import time, os, threading
import sys
import subprocess
from config import APIConfig
from FTPServer import dowloadFIle
import time
'''
sudo top
killall
'''


##############################################
route = "openFrameworks/autoActualizacion/" ##ruta de almacenamiento y estracion de archivos
dirEjecutable = "EJECUTABLE"                  ##nombre de la carpeta donde se instalara y ejecutara el proyecto
dirRest = "REST"                            ##nombre de la carpeta donde se obtendran las actualizaciones
dirRespaldo = "RESPALDO"                       ##nombre de la carpeta donde se guardaran los respaldos de las versiones 
##############################################


#Ejecuta el proyecto en C++ de OF, el cual es externo a python 
def ejecutarActualizacion(version):
        print("ejecutando version: {} \n".format(version))
        subprocess.getstatusoutput('cd {}{}/{} && make run'.format(route,dirEjecutable,version))
        print("version: {} detenida \n".format(version))
        print("\n--------------------------------------")
        sys.exit()#matamos el hilo

#Crea un hilo y lo configura como demonio
def funct_hilo(version_actual):
    hilo2 = threading.Thread(target=ejecutarActualizacion, args=(version_actual,))
    hilo2.daemon = True
    hilo2.start()
  

#Creamos las carpetas si es que aun no existen
filtro = lambda _dir: _dir if _dir == dirEjecutable or _dir == dirRespaldo else None
def mkdir():
        list_dirs = subprocess.getstatusoutput('cd {} && ls'.format(route))
        list_dirs = clean(list_dirs[1])
        #existe_carpeta = [_dir if _dir == "EJECUTABLE" or _dir == "RESPALDO" else None for _dir in list_dirs]
        ejecutable = True
        respaldo = True
        existe_carpeta = filter(filtro,list_dirs)      
        for i in list(existe_carpeta):
                if i == dirEjecutable:
                        ejecutable = False
                elif i == dirRespaldo:
                        respaldo = False
        if ejecutable:
                subprocess.getstatusoutput('cd {} && mkdir {}'.format(route,dirEjecutable))
        if respaldo:
                subprocess.getstatusoutput('cd {} && mkdir {}'.format(route,dirRespaldo))


#Preprocesa los datos obtenidos mediante el comando ls en la carpeta REST
def clean(lista_versiones):
        lista_versiones += '\n'
        lista = []
        date = ''
         
        for  i in lista_versiones:
            #print(i)
            if (i != '\n' and i):
                date += i
            else:
                lista.append(date)
                date  =''
        
        if lista[0] == '':
            lista = ''
        return(lista)
"""
def delateZip(ultima_version_zip):
        ultima_version = ''
        for i in ultima_version_zip:
                if i == '.':
                        break
                else:
                        ultima_version += i
        return ultima_version
"""     
        
def main():
        killthread = False
        version_actual = ''
        hayAnterior = False
        error = True
        mkdir()
        while(True):
                try:
                        time.sleep(2)
                        ultima_version, initPublic, endPublic = APIConfig()#Revisamos en la api la ultima actualizacion 
                                
                        if ultima_version != version_actual:
                                killthread = False
                                print("Hay una nueva actualizacion \n")  
                                versionZip = ultima_version + "{}".format(".zip")
                                dowloadFIle(versionZip)#Descargamos la version del servidor FTP  
                                subprocess.getstatusoutput('unzip {0} && rm -r {0}'.format(versionZip))#Descomprimimos .zip no debe existir mas de dos veces ese archivo por que va amarcar error
                                #Descargamos (De la carpeta REST copiamos la ultima version y la pegamos en EJECUTABLE)
                                subprocess.getstatusoutput('cp -r {0} {1}{2} && rm -r {0}'.format(ultima_version,route,dirEjecutable))#cp -r ruta/carpeta/ nuevaruta/nuevo nombre
                               
                                #Revisamos si existe una version anterior
                                if hayAnterior:           
                                        #Respaldamos la version anterior    
                                        subprocess.getstatusoutput('cp -r {}{}/{} {}{}'.format(route,dirEjecutable,version_actual,route,dirRespaldo))#cp -r ruta/carpeta/ nuevaruta/nuevo nombre
                                        #Borrar la version pasada si es que habia una
                                        subprocess.getstatusoutput('rm -r {}{}/{}'.format(route,dirEjecutable,version_actual))
                                        #Eliminamos el hilo anteriormente ejecutado
                                        subprocess.getstatusoutput('killall {}'.format(version_actual))
                                        
                                #La ultima version ahora es la v
                                version_actual = ultima_version      
                                error = True  
                                hayAnterior = True #indicamos que ya hay una version anterior para futuras referencias 
                                """Ejecutamos hilo 2 se encarga de buscar actualizaciones y reiniciar el sistema"""
                                funct_hilo(version_actual)
                                
                except(IndexError, TypeError):
                        
                        if error:
                                error = False
                                

                        if hayAnterior:
                                killthread = True
                        


if __name__ == "__main__":
        main()
    


