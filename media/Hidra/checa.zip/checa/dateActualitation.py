from datetime import datetime

date = {'year': '2019', 'month': '07', 'day': '24', 'time': '18:07:14'}

while():
    print("hola")
    #https://pymotw.com/3/datetime/