import ftplib

def dowloadFIle(nameFile):
    filename = nameFile
    ftp = ftplib.FTP("192.168.15.7")
    ftp.login("roberto", "1234")
    ftp.cwd("/ftp_archivos")
    #ftp.retrlines('LIST') #Listar archivos en el servidor FTP
    
    try:
        ftp.retrbinary("RETR " + filename ,open(filename, 'wb').write)
        print("Descarga exitosa de {} ".format(nameFile))
    except Exception as e:
        print ("Error " + str(e))

def dowloadDirect():
    # Connection information
    server = "192.168.15.7"
    username = "roberto"
    password = "1234"
    
    # Directory and matching information
    directory = '/expl/publico/MI_DIRECTORIO/'
    filematch = '*.txt'
    
    # Establish the connection
    ftp = ftplib.FTP(server)
    ftp.login(username, password)
    
    # Change to the proper directory
    ftp.cwd(directory)
    
    # Loop through matching files and download each one individually
    for filename in ftp.nlst(filematch):
        fhandle = open(filename, 'wb')
        print ('Getting ' + filename)
        ftp.retrbinary('RETR ' + filename, fhandle.write)
        fhandle.close()