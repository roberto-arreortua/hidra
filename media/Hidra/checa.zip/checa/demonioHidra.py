import time, os, threading
import sys
import subprocess


'''
sudo top
killall
'''


##############################################
route = "openFrameworks/autoActualizacion/" ##ruta de almacenamiento y estracion de archivos
dirEjecutable = "EJECUTABLE"                  ##nombre de la carpeta donde se instalara y ejecutara el proyecto
dirRest = "REST"                            ##nombre de la carpeta donde se obtendran las actualizaciones
dirRespaldo = "RESPALDO"                       ##nombre de la carpeta donde se guardaran los respaldos de las versiones 
##############################################


#Ejecuta el proyecto en C++ de OF, el cual es externo a python 
def ejecutarActualizacion(version):
        print("ejecutando version: {} \n".format(version))
        subprocess.getstatusoutput('cd {}{}/{} && make run'.format(route,dirEjecutable,version))
        print("version: {} detenida \n".format(version))
        print("\n--------------------------------------")
        sys.exit()#matamos el hilo

#Crea un hilo y lo configura como demonio
def funct_hilo(version_actual):
    hilo2 = threading.Thread(target=ejecutarActualizacion, args=(version_actual,))
    hilo2.daemon = True
    hilo2.start()
  

#Creamos las carpetas si es que aun no existen
filtro = lambda _dir: _dir if _dir == dirEjecutable or _dir == dirRespaldo else None
def mkdir():
        list_dirs = subprocess.getstatusoutput('cd {} && ls'.format(route))
        list_dirs = clean(list_dirs[1])
        #existe_carpeta = [_dir if _dir == "EJECUTABLE" or _dir == "RESPALDO" else None for _dir in list_dirs]
        ejecutable = True
        respaldo = True
        existe_carpeta = filter(filtro,list_dirs)      
        for i in list(existe_carpeta):
                if i == dirEjecutable:
                        ejecutable = False
                elif i == dirRespaldo:
                        respaldo = False
        if ejecutable:
                subprocess.getstatusoutput('cd {} && mkdir {}'.format(route,dirEjecutable))
        if respaldo:
                subprocess.getstatusoutput('cd {} && mkdir {}'.format(route,dirRespaldo))


#Preprocesa los datos obtenidos mediante el comando ls en la carpeta REST
def clean(lista_versiones):
        lista_versiones += '\n'
        lista = []
        date = ''
         
        for  i in lista_versiones:
            #print(i)
            if (i != '\n' and i):
                date += i
            else:
                lista.append(date)
                date  =''
        
        if lista[0] == '':
            lista = ''
        return(lista)
        
        
def main():
        version_actual = ''
        hayAnterior = False
        error = True
        mkdir()
        while(True):
                lista_versiones = subprocess.getstatusoutput('cd {}{}/ && ls'.format(route,dirRest))
                lista_versiones = (lista_versiones[1])
                lista_versiones = clean(lista_versiones)#funcion para limpiar los datos de listado LINUX
                try:
                        ultima_version = lista_versiones[len(lista_versiones)-1] #try
                        if ultima_version != version_actual :
                                print("Hay una nueva actualizacion \n")  
                                #Descargamos (De la carpeta REST copiamos la ultima version y la pegamos en EJECUTABLE)
                                subprocess.getstatusoutput('cp -r {}{}/{} {}{}'.format(route,dirRest,ultima_version,route,dirEjecutable))#cp -r ruta/carpeta/ nuevaruta/nuevo nombre
                               
                                #Revisamos si existe una version anterior
                                if hayAnterior:           
                                        #Respaldamos la version anterior    
                                        subprocess.getstatusoutput('cp -r {}{}/{} {}{}'.format(route,dirEjecutable,version_actual,route,dirRespaldo))#cp -r ruta/carpeta/ nuevaruta/nuevo nombre
                                        #Borrar la version pasada si es que habia una
                                        subprocess.getstatusoutput('rm -r {}{}/{}'.format(route,dirEjecutable,version_actual))
                                        #Eliminamos el hilo anteriormente ejecutado
                                        subprocess.getstatusoutput('killall {}'.format(version_actual))
                                        
                                #La ultima version ahora es la v
                                version_actual = ultima_version      
                                error = True  
                                hayAnterior = True #indicamos que ya hay una version anterior para futuras referencias 
                                """Ejecutamos hilo 2 se encarga de buscar actualizaciones y reiniciar el sistema"""
                                funct_hilo(version_actual)
                except(IndexError):
                        if error:
                                print("No hay ninguna version en el servidor \n")
                                error = False
                                hayAnterior = False


if __name__ == "__main__":
        main()
    


