import requests
import json

def dateFormat(dateParam):
    date = []
    datetime = ''
    for char in dateParam:
        if char == '-' or char == 'T' or char == 'Z':
            date.append(datetime)
            datetime = ''
        else:
            datetime += char
    dataDic = {'year':date[0],'month':date[1],'day':date[2],'time':date[3]}
    
    
    return(dataDic)


def getToken():
    url = 'http://127.0.0.1:8000/rest-auth/login/'
    username = 'roberto'
    password = '1234'
    data = {'username':username,'password':password}
    Token = requests.post(url,data=data)
    print("Login Token {} /n".format(Token))
    Token = Token.json()
    Token = Token['key']
    return(Token)

def logOutAPI(Token):
    url = 'http://127.0.0.1:8000/rest-auth/logout/'
    request = requests.post(url, headers= {'Authorization': 'Token {}'.format(Token)}) 
    print("Logout Token {} /n".format(request))
    




def APIConfig():
    try:
        Token = getToken()
        url = 'http://127.0.0.1:8000/api/v1.0/config'
        #requests GET to the API
        responseJ = requests.get(url, headers= {'Authorization': 'Token {}'.format(Token)}) 
        print("get API {} /n".format(responseJ))
        response = responseJ.json()
        config  = response[0]
        idVersion = config['id']
        published = config['published']
        version = config['version']
        dateinit = config['fecha_publicacion']
        dateend = config['fecha_despublicacion']
        #date =  {'year':'','month':'','day':'','hour':''}
        dateinit = dateFormat(dateinit)
        dateend = dateFormat(dateend)
        logOutAPI(Token)
        return(version,dateinit,dateend, idVersion,published)
        #print(dateinit, dateend)
    except:
        print("Error al conectarce a la API")
    

def PublishedVersion(id):
    try:
        Token = getToken()
        url = 'http://127.0.0.1:8000/api/v1.0/config/{}/'.format(id)
        responseJ = requests.get(url,headers= {'Authorization': 'Token {}'.format(Token)})
        print("get/put API {} /n".format(responseJ))
        config = responseJ.json()
        config['published'] = True
        response = requests.put(url,data=config,headers= {'Authorization': 'Token {}'.format(Token)})#<Response [200]>
        print("put API {} /n".format(response))
        logOutAPI(Token)
    except:
        print("Error al conectarce con la APi")
        
    