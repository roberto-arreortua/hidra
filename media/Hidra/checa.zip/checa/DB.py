import sqlite3 


#Variable Global 
ids = ''




""" Funciones par conectarce y desconectarce a la BDD """

def desConection(Conection):
    Conection.close()
def Conect():
    Conection = sqlite3.connect("UPGRADES")
    Cursor = Conection.cursor()
    return Conection, Cursor
    

"""Funcion para crear la BDD"""
def CreateDB():
    Conection, Cursor = Conect()
    try:
        Cursor.execute("CREATE TABLE UPGRADES (id PRIMARYKEY,version VARCHAR(50), fecha_publicacion DATETIME, fecha_despublicacion DATETIME, priority BOOLEAN, published BOOLEAN)")
        print("Base de Datos Creada")
        desConection(Conection)
    except:
        pass

"""Funcion para guardar en la BDD versiones traidas de la API que no hayan sido publicadas pero que no existan en la BDD"""
#Funcion para el FIlter 
def finid(id):
    global ids
    x = [i if id == i else False for  i in ids] #si en los ids de la BDD hay un id igual lo marcamos con un True
    for  i in x:
        if (i):
            return(None)
    return(id)

def ListUpgrade(upgrades):
    global ids
    versions = []
    CreateDB()
    Conection, Cursor = Conect()
    #Hacemos una consulta para traer los id de los registros anteriores que no hayan sido publicados 
    Cursor.execute("SELECT id From UPGRADES WHERE published = 0")
    query = Cursor.fetchall()
    ids = [id[0] for id in query]#ids de la BDD
    Conection.commit()
    #De todos los registros enviados por la api ver cuales han sido publicados
    for upgrade in upgrades:
        if not(upgrade['published']):
            versions.append(upgrade) #lista con versiones que no han sido publicadas 
    
    ids = list(filter(finid, [version["id"] for version in versions]))
    for  id in ids:
        for upgrade in upgrades:
            if id == upgrade['id']:
                Insert = [
                    (upgrade['id'],upgrade['version'],upgrade['fecha_publicacion'],
                    upgrade['fecha_despublicacion'],upgrade['priority'],upgrade['published'])
                ]
                Cursor.executemany("INSERT INTO UPGRADES VALUES (?,?,?,?,?,?)", Insert)
                Conection.commit()
    desConection(Conection)



"""FUncion para traer de la BDD todas las versiones que aun no han sido publicadas ordenadas por fecha
   Retorna la version con la fecha proxima a la fecha de hoy"""

def Next():
    Conection,Cursor = Conect()
    Cursor.execute("SELECT * From UPGRADES WHERE published = 0 ORDER BY fecha_publicacion ASC")#en el demon2 se checa si la fecha ya paso, de ser asi marcarlo como published
    query = Cursor.fetchall()
    Conection.commit()
    #si el primer registro esta basio toma el siguiente
    for i in query:
        if i[0] == None or i[1] == None or i[2] == None  or i[3] == None or i[0] == '' or i[1] == '' or i[2] == ''  or i[3] == '' :
            pass
        else:
            version = i
            break

    desConection(Conection)
    try:
        return(version, True)
    except:
        return("No hay versiones disponibles", False)
    

""" Funcion para declarar la version como publicada published = True"""

def PublishedVersionSQL(id):
    Conection,Cursor = Conect()
    Cursor.execute("UPDATE UPGRADES SET published = 1 WHERE id = {}".format(id))
    Conection.commit()
    desConection(Conection)