import requests
import json
from DB import ListUpgrade, Next




"""Esta funcion extraer los datos de la variable dateParam y crea un diccionario mas facil de procesar"""
def dateFormat(dateParam):
    date = []
    datetime = ''
    for char in dateParam:
        if char == '-' or char == 'T' or char == 'Z':
            date.append(datetime)
            datetime = ''
        else:
            datetime += char
    dataDic = {'year':date[0],'month':date[1],'day':date[2],'time':date[3]}
    return(dataDic)


"""Consumo de la API para generear un token y poder consumir la API de config"""
#LOGIN
def getToken():
    url = 'http://127.0.0.1:8000/rest-auth/login/'
    username = 'roberto'
    password = '1234'
    data = {'username':username,'password':password}
    Token = requests.post(url,data=data)
    print("Login Token {} \n".format(Token))
    Token = Token.json()
    Token = Token['key']
    return(Token)
#LOGOUT
def logOutAPI(Token):
    url = 'http://127.0.0.1:8000/rest-auth/logout/'
    request = requests.post(url, headers= {'Authorization': 'Token {}'.format(Token)}) 
    print("Logout Token {} \n".format(request))
    




"""Consumo de la API config mediante un Token,obtenemos un JSON con los datos de configuracion, guardamos las configuraciones en la BDD"""
def APIConfig():
    try:
        Token = getToken()
        url = 'http://127.0.0.1:8000/api/v1.0/config'
        #requests GET to the API
        responseJ = requests.get(url, headers= {'Authorization': 'Token {}'.format(Token)}) 
        logOutAPI(Token)
        print("get API {} \n".format(responseJ))
        response = responseJ.json()
        ListUpgrade(response)#Guardamos los datos en la BDD SQL
    except:
        print("Error al conectarce a la API")
    

"""Funcion para cambiar el estado de published en la base de datos de Django de la publicacion recien ejecutada por el domonio""" 
def PublishedVersion(id):
    try:
        Token = getToken()
        url = 'http://127.0.0.1:8000/api/v1.0/config/{}/'.format(id)
        responseJ = requests.get(url,headers= {'Authorization': 'Token {}'.format(Token)})
        print("get/put API {} \n".format(responseJ))
        config = responseJ.json()
        config['published'] = True
        response = requests.put(url,data=config,headers= {'Authorization': 'Token {}'.format(Token)})#<Response [200]>
        print("put API {} \n".format(response))
        logOutAPI(Token)
    except:
        print("Error al conectarce con la APi")
        

"""Funcion para traer de la BDD la ultima version """
def NextVersion():
    version, hayVersion = Next()
    print(version)
    if(hayVersion):
        boolean = [False,True]
        id = version[0]
        name = version[1]
        dateinit = dateFormat(version[2])#formato de fecha
        dateend = dateFormat(version[3])#formato de fecha
        priority = boolean[version[4]]
        published = boolean[version[5]]
        return(name,dateinit,dateend,id,published,True)
    else:
        print(version)
    




#############Recuerda borrar los basiosss por que se esta llenando con cosas basias aguas